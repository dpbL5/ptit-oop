package javaXX;
import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws FileNotFoundException {
        Scanner in = new Scanner(new File("SINHVIEN.in"));
        ArrayList<Sinhvien> sv = new ArrayList<>();
        int t = Integer.parseInt(in.nextLine());
        while (t-- > 0)
            sv.add(new Sinhvien(in.nextLine(), in.nextLine(), in.nextLine(), in.nextLine()));
        Collections.sort(sv);
        for (Sinhvien i : sv) 
            System.out.println(i);
    }
}
