package thuctapcoso;

/**
 * SinhVien
 */
public class SinhVien {

    String id;
    String name;
    String phoneNum;
    String email;

    public SinhVien(String id, String name, String phoneNum, String email){ 
        this.id = id;
        this.name = name;
        this.phoneNum = phoneNum;
        this.email = email;
    }
}