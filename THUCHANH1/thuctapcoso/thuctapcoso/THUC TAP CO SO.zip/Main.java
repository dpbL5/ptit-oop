package thuctapcoso;

import java.io.*;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) 
    throws  FileNotFoundException{
        Scanner in = new Scanner(new File("SINHVIEN.in"));
        int n = in.nextInt(); in.nextLine();
        ArrayList<SinhVien> svList = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            svList.add(new SinhVien(
                in.nextLine(), in.nextLine(), in.nextLine(), in.nextLine()));
        }
        in.close();

        in = new Scanner(new File("DETAI.in"));
        n = in.nextInt();
        in.nextLine();
        ArrayList<DeTai> dtList = new ArrayList<>();
        for (int i = 0 ; i < n; i++) {
            dtList.add(new DeTai(i+1, in.nextLine(), in.nextLine()));
        }
        in.close();

        in = new Scanner(new File("NHIEMVU.in"));
        n = in.nextInt();
        ArrayList<NhiemVu> nvList = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            String id = in.next();
            String idDT = in.next();
            for (SinhVien sv :svList) {
                if (sv.id.equals(id)) {
                    for (DeTai dt: dtList) {
                        if (dt.id.equals(idDT)) {
                            nvList.add(new NhiemVu(sv, dt));
                        }
                    }
                }
            }
        }
        Collections.sort(nvList);
        for (NhiemVu nv : nvList) {
            System.out.println(nv);
        }
        in.close();
    }
}
