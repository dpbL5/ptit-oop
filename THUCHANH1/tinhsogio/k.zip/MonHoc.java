package tinhsogio;

/**
 * MonHoc
 */
public class MonHoc {

    private String maMon;
    private String tenMon;

    public MonHoc (String ma, String ten) {
        this.maMon = ma;
        this.tenMon = ten;
    }

}